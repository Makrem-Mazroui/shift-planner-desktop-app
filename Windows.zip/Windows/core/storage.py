import json
import os
from datetime import datetime

def load_members(json_path):
    if os.path.exists(json_path):
        with open(json_path, "r") as f: 
            members = json.load(f)
            # Ensure every member has a 'skills' dictionary and 'level'
            for m in members:
                if "skills" not in m: m["skills"] = {}
                if "level" not in m: m["level"] = "Senior"
                if "email" not in m: m["email"] = ""
            return members
    return []

def save_members(members, json_path):
    with open(json_path, "w") as f: 
        json.dump(members, f, indent=4)

def load_schedule(data_path):
    if os.path.exists(data_path):
        with open(data_path, "r") as f:
            data = json.load(f)
            for s in data["shifts"]:
                if isinstance(s["start"], str):
                    s["start"] = datetime.strptime(s["start"], "%Y-%m-%d")
                if isinstance(s["end"], str):
                    s["end"] = datetime.strptime(s["end"], "%Y-%m-%d")
            if "absences" not in data: data["absences"] = []
            if "comp_days" not in data: data["comp_days"] = [3, 4]
            return data
    return None

def save_schedule(shifts, year, plan_type, shift_config, times, staffing, country, absences, comp_days, data_path):
    serializable_shifts = []
    for s in shifts:
        s_copy = s.copy()
        if isinstance(s["start"], datetime):
            s_copy["start"] = s["start"].strftime("%Y-%m-%d")
        if isinstance(s["end"], datetime):
            s_copy["end"] = s["end"].strftime("%Y-%m-%d")
        serializable_shifts.append(s_copy)
    
    if absences is None: absences = []
    if comp_days is None: comp_days = [3, 4]

    data = {
        "year": year, 
        "plan_type": plan_type, 
        "shift_config": shift_config,
        "times": times, 
        "staffing": staffing, 
        "country": country, 
        "shifts": serializable_shifts,
        "absences": absences,
        "comp_days": comp_days
    }
    with open(data_path, "w") as f: json.dump(data, f, indent=4)