import os
import uuid
import platform
import hashlib
import base64
from datetime import datetime
from config import BASE_DIR  # Import the fix

# We handle the import error in main.py or app.py
try:
    from cryptography.hazmat.primitives import serialization, hashes
    from cryptography.hazmat.primitives.asymmetric import padding
except ImportError:
    pass

class LicenseManager:
    # FIX: Use absolute path next to the app
    LICENSE_FILE = os.path.join(BASE_DIR, "license.dat")
    
    PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4aj1hpN6eaWUPDvTxsaV
ony6ni4L+xCorE0FFH3Xzo4pVRI+gnSznG/c0YBh7DhnDdidE3170xiyApN0K4Cx
ewA1KFzYMFC0OBWIBykFIZOhkVClrioNcP7cRBBII/GaL+GjWTcffwUDO7a0R31k
U0xEu1koNG0ev6z2oLIN0W5JBno6dzNOxB/BeHL2rrLYmINDCwKAXkd5Pl8WCzNB
XAgBAaJPgOoqoGmPxmuaL8XjuTyTZh2z4IEyw7eaaXlxBpbUjrV2rwcxZW83yArx
ATp0WZBDkx475JJmrHbfsCs+jVsatTAJ1UPBgvDhQMAyad65M9mKZ4eMKC7t7SGZ
uwIDAQAB
-----END PUBLIC KEY-----"""

    @staticmethod
    def get_hwid():
        try:
            mac = uuid.getnode()
            node = platform.node()
            system = platform.system()
            raw_id = f"{mac}-{node}-{system}"
            return hashlib.md5(raw_id.encode()).hexdigest().upper()[:20]
        except:
            return "UNKNOWN-HWID-ERROR"

    @staticmethod
    def verify_license():
        if not os.path.exists(LicenseManager.LICENSE_FILE):
            return False, "No license found.", None
            
        try:
            with open(LicenseManager.LICENSE_FILE, "r") as f:
                key_text = f.read().strip()
                
            if "." not in key_text:
                return False, "Invalid license format (Old key?)", None
            
            payload_b64, sig_b64 = key_text.split(".")
            
            payload = base64.b64decode(payload_b64)
            signature = base64.b64decode(sig_b64)
            
            try:
                public_key = serialization.load_pem_public_key(LicenseManager.PUBLIC_KEY_PEM)
            except ValueError:
                return False, "Public Key Configuration Error in App", None

            try:
                public_key.verify(
                    signature,
                    payload,
                    padding.PKCS1v15(),
                    hashes.SHA256()
                )
            except Exception:
                return False, "License signature invalid (Tampered).", None
            
            data_str = payload.decode('utf-8')
            parts = data_str.split("|")
            
            if len(parts) != 2: return False, "Corrupted license data.", None
            
            hwid, exp_str = parts[0], parts[1]
            
            current_hwid = LicenseManager.get_hwid()
            if hwid != current_hwid:
                return False, "License is for a different machine.", None
                
            exp_date = datetime.strptime(exp_str, "%Y-%m-%d")
            if datetime.now() > exp_date:
                return False, f"License expired on {exp_str}.", None
                
            return True, "Active", exp_str
            
        except Exception as e:
            return False, f"Error: {str(e)}", None
    
    @staticmethod
    def save_license(key):
        with open(LicenseManager.LICENSE_FILE, "w") as f:
            f.write(key)
