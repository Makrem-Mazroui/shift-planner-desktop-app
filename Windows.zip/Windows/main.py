import tkinter as tk
from tkinter import messagebox
import sys

# Check for critical dependencies before starting
try:
    import cryptography
except ImportError:
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror("Error", "Missing 'cryptography' library.\nPlease run: pip install cryptography")
    sys.exit()

from ui.app import ShiftPlannerApp

if __name__ == "__main__":
    app = ShiftPlannerApp()
    app.mainloop()